import cv2
import numpy as np    
import pytesseract
import matplotlib.pyplot as plt
import maxflow
##needs pymaxflow as well

#author: Ian Holmes ihholmes@ncsu.edu

img=cv2.imread('Denoisedimage.jpg', cv2.IMREAD_GRAYSCALE)
#credit to: https://docs.opencv.org/4.x/d9/d61/tutorial_py_morphological_ops.html
kernel = np.ones((3,3),np.uint8)
img = cv2.dilate(img, kernel, iterations = 1)

h,w = img.shape
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
#Obtain boxes
TestConfig = r'--psm 6'
boxes=pytesseract.image_to_boxes(img, config=TestConfig)
#For loop to draw rectangles on detected boxes
boxList = []
for b in boxes.splitlines():
    b=b.split(' ')
    b[1] = int(b[1]) #xmin
    b[2] = int(b[2]) #ymin
    b[3] = int(b[3]) #xmax (width)
    b[4] = int(b[4]) #ymax (height)
    boxList.append(b)

#xDP = 10, yDP = 20 seems good
#xDP = 8, yDP = 20 seems good
xDP = 8
yDP = 25

#image these coordinates as a pair of vertical lines
def overlapY(firstYMin, firstYMax, secondYMin, secondYMax):
    #if one line is in the middle of the other:
    if (firstYMin < secondYMin and firstYMax > secondYMax or
        secondYMin < firstYMin and secondYMax > firstYMax):
        return True
    #if one vertical line ends before the other begins, there is no overlap
    if (firstYMax < secondYMin or secondYMax < firstYMin):
        return False #no overlap
    if firstYMin - yDP <= secondYMin <= firstYMin + yDP:
        if firstYMax - yDP <= secondYMax <= firstYMax + yDP:
            return True
    else:
        ##print("overlapY edge case reached")
        ##print(firstYMin, firstYMax, secondYMin, secondYMax)
        return False

def overlapX(firstXMin, firstXMax, secondXMin, secondXMax):
    if (firstXMin < secondXMin and firstXMax > secondXMax or
        secondXMin < firstXMin and secondXMax > firstXMax):
        return True
    if (firstXMax - xDP <= secondXMin <= firstXMax + xDP): #set to OR to get lines
        return True
    else:
        return False

def mergeBoxes(boxList):
    for i in range(len(boxList)):
        for j in range(len(boxList)):
            b1 = boxList[i]
            b2 = boxList[j]
            if (b1[1] == b2[1] and b1[2] == b2[2] and b1[3] == b2[3] and b1[4] == b2[4]):
                continue
            verticalOverlap = overlapY(b1[2], b1[4], b2[2], b2[4])
            #print(verticalOverlap)
            if not verticalOverlap:
                continue
            horizontalOverlap = overlapX(b1[1], b1[3], b2[1], b2[3])
            #print(horizontalOverlap)
            if (verticalOverlap and horizontalOverlap):
                boxList.remove(b1)
                boxList.remove(b2)
                newXMin = min(b1[1], b2[1])
                newYMin = min(b1[2], b2[2])
                newXMax = max(b1[3], b2[3])
                newYMax = max(b1[4], b2[4])
                boxList.append(["", newXMin, newYMin, newXMax, newYMax])
                #print(["", newXMin, newYMin, newXMax, newYMax])
                return(boxList)
    return boxList

##boxList = []
##boxList.append(["", 5, 5, 10, 10])
##boxList.append(["", 6, 6, 11, 9])
##boxList.append(["", 11, 6, 16, 11])
##boxList.append(["", 30, 5, 35, 10])
##boxList.append(["", 6, 6, 9, 9])
##boxList.append(["", 1, 1, 40, 40])


##while(True):
##    size = len(boxList)
##    if (size % 100 == 0):
##        print(size)
##    boxList = mergeBoxes(boxList)
##    if (size == len(boxList)):
##        break
            
##for b in boxList:
##    print(b)

img=cv2.imread('Denoisedimage.jpg')

for b in boxList:
    segmentedimg=cv2.rectangle(img,(int(b[1]),h-int(b[2])), (int(b[3]), h-int(b[4])) ,(0,255,0),2)
  
#Display image
cv2.imshow('segmented_image.jpg',segmentedimg)
cv2.imwrite("segmented_image.jpg",segmentedimg)
cv2.waitKey(0)
cv2.destroyAllWindows()
