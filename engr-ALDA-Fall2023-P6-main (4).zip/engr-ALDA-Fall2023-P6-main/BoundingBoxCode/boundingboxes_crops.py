import cv2
import numpy as np    
import pytesseract
import matplotlib.pyplot as plt
import maxflow
##needs pymaxflow as well

#author: Ian Holmes ihholmes@ncsu.edu

img=cv2.imread('1.jpg', cv2.IMREAD_GRAYSCALE)
#credit to: https://docs.opencv.org/4.x/d9/d61/tutorial_py_morphological_ops.html
#this is where we perform dilation (reversed erosion)
kernel = np.ones((3,3),np.uint8)
img = cv2.dilate(img, kernel, iterations = 1)

#Obtain boxes
h,w = img.shape
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
TestConfig = r'--psm 6'
boxes=pytesseract.image_to_boxes(img, config=TestConfig)

#For loop to draw rectangles on detected boxes
boxList = []
for b in boxes.splitlines():
    b=b.split(' ')
    b[1] = int(b[1]) #xmin
    b[2] = int(b[2]) #ymin
    b[3] = int(b[3]) #xmax (width)
    b[4] = int(b[4]) #ymax (height)
    boxList.append(b)

#distance parameters specify the allowable distance between rectangles
#if the distance is less than the parameter, they are merged
#xDP = 10, yDP = 20 seems good
#xDP = 8, yDP = 20 seems good
xDP = 10
yDP = 15

#imagine these coordinates as a pair of vertical lines
def overlapY(firstYMin, firstYMax, secondYMin, secondYMax):
    #if one line is in the middle of the other:
    if (firstYMin < secondYMin and firstYMax > secondYMax or
        secondYMin < firstYMin and secondYMax > firstYMax):
        return True
    #if one vertical line ends before the other begins, there is no overlap
    if (firstYMax < secondYMin or secondYMax < firstYMin):
        return False #no overlap
    if firstYMin - yDP <= secondYMin <= firstYMin + yDP:
        if firstYMax - yDP <= secondYMax <= firstYMax + yDP:
            return True
    else:
        return False
    
def above(firstYMin, firstYMax, secondYMin, secondYMax):
    if (firstYMin < secondYMin and firstYMax <= secondYMax):
        return true

#similarly, this determines if the two lines overlap
#or are within the xDP of each other
def overlapX(firstXMin, firstXMax, secondXMin, secondXMax):
    if (firstXMin < secondXMin and firstXMax > secondXMax or
        secondXMin < firstXMin and secondXMax > firstXMax):
        return True
    if (firstXMax - xDP <= secondXMin <= firstXMax + xDP): #set to OR to get lines
        return True
    else:
        return False

#uses the above two methods to combine overlapping boxes
def mergeBoxes(boxList):
    for i in range(len(boxList)):
        for j in range(len(boxList)):
            b1 = boxList[i]
            b2 = boxList[j]
            if (b1[1] == b2[1] and b1[2] == b2[2] and b1[3] == b2[3] and b1[4] == b2[4]):
                continue
            verticalOverlap = overlapY(b1[2], b1[4], b2[2], b2[4])
            if not verticalOverlap:
                continue
            horizontalOverlap = overlapX(b1[1], b1[3], b2[1], b2[3])
            if (verticalOverlap and horizontalOverlap):
                boxList.remove(b1)
                boxList.remove(b2)
                newXMin = min(b1[1], b2[1])
                newYMin = min(b1[2], b2[2])
                newXMax = max(b1[3], b2[3])
                newYMax = max(b1[4], b2[4])
                boxList.append(["", newXMin, newYMin, newXMax, newYMax])
                return(boxList)
    return boxList

#for loop to combine boxes using mergeBoxes()
while(True):
    size = len(boxList)
    if (size % 100 == 0):
        print(size)
    boxList = mergeBoxes(boxList)
    if (size == len(boxList)):
        break

img=cv2.imread('1.jpg')

newBoxList = boxList.copy()
boxList = []

for b in newBoxList:
    if (b[1] == 34 and h-b[2] == 75):
        print("found")
    if b[1] > b[3]:
        holder = b[1].copy()
        b[1] = b[3]
        b[3] = holder
    if h - b[2] > h - b[4]:
        holder = b[2]
        b[2] = b[4]
        b[4] = holder
        print("true")
    boxList.append(b)

boxList = sorted(boxList, key= lambda x: h - x[2])

for b in boxList:
    segmentedimg=cv2.rectangle(img,(int(b[1]),h-int(b[2])), (int(b[3]), h-int(b[4])) ,(0,255,0),2)
    print(str(b[1]) + "," + str(h - int(b[2])))
    print(str(b[3]) + "," + str(h - int(b[4])))
  
cv2.imshow('segmented_image.jpg',segmentedimg)
cv2.imwrite("segmented_image.jpg",segmentedimg)
cv2.waitKey(0)
cv2.destroyAllWindows()










