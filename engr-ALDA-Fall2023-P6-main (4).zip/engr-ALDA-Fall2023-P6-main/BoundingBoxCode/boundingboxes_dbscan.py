import cv2
import numpy as np    
import pytesseract
import matplotlib.pyplot as plt
import maxflow
import sklearn
import random as rd
import matplotlib.cm as cm
##needs pymaxflow as well

#author: Ian Holmes ihholmes@ncsu.edu

#iterate for every image in imgs
imgs = ["0.jpg", "11.jpg", "22.jpg"]

for i in imgs:

    img = cv2.imread(i, cv2.IMREAD_GRAYSCALE)
    (thresh, img_bw) = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    #cv2.imshow('img_bw.jpg',img_bw)
    img_bw = [*zip(*img_bw)]
    xCoordinates = []
    yCoordinates = []
    coordinates = []
    #create a matrix representation of the image
    #remember that coordinates are reversed in image_bw
    #might need to reverse coordinates
    for i in range(len(img_bw)):
        for j in range(len(img_bw[i])):
            if img_bw[i][j] == 0:
                xCoordinates.append(i)
                yCoordinates.append(j)
                #add x and y in reversed order
                coordinates.append([j, i])
    ##plt.scatter(yCoordinates, xCoordinates, s=0.01)
    ##plt.axis('scaled')
    ##plt.show()

    from sklearn import metrics
    from sklearn.cluster import DBSCAN

    #credit to https://medium.com/@tarammullin/dbscan-parameter-estimation-ff8330e3a3bd
    from sklearn.neighbors import NearestNeighbors
    from matplotlib import pyplot as plt

    #use KNN to select best parameters
    #fix minPts, use KNN to select best value of epsilon
    neighbors = NearestNeighbors(n_neighbors=10)
    neighbors_fit = neighbors.fit(coordinates)
    distances, indices = neighbors_fit.kneighbors(coordinates)
    distances = np.sort(distances, axis=0)
    distances = distances[:,1]
    #show KNN graphs individually
    plt.plot(distances)
    plt.show()

    #eps = 5, minPts = 10
    db = DBSCAN(eps=5, min_samples=10).fit(coordinates)
    labels = db.labels_
    #get a unique set of the cluster labels for color assignment
    unique_labels = set(labels)

    colors = [int(i) % len(unique_labels) for i in labels]

    plt.figure(figsize = (10,10));
    #use tab10 for good alternating colors
    plt.scatter(yCoordinates, xCoordinates, c=colors, cmap='tab10', s=0.01)
    plt.axis('scaled')
    plt.show()











