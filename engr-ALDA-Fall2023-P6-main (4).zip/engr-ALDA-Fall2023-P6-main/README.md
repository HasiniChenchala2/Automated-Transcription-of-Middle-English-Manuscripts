# engr-ALDA-Fall2023-P6
Project group 6 for ALDA Fall 2023

ManuscriptData: Contains the manuscript image used for data, the XML file for that image, and the output (.txt) file generated from that XML file

BoundingBoxes: Manually created bounding boxes for 21 different words

BoundingBoxCode: Data and Python code used for automatically creating bounding boxes

ANN: Data and Python code used for training the ANN model

LinearRegression.ipynb: Python code used for linear regression (prediction of letter count based on pixel width)

iter1: Data for Linear Regression

xmltotext.py: Using XML file for the manuscript, obtained the output.txt file which reads every line from poem
