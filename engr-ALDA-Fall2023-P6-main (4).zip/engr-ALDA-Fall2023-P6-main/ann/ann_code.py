import os
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from tensorflow.keras.utils import to_categorical

# Specify the path of the parent folder containing image folders
parent_folder_path = 'ann'

# Get a list of folder names
folders_temp = [folder for folder in os.listdir(parent_folder_path) if os.path.isdir(os.path.join(parent_folder_path, folder))]

folders = [ele for ele in folders_temp if ele not in ['slash']]
print(folders)

# Load and preprocess your dataset
data = []
labels = []

for folder in folders:
    folder_path = os.path.join(parent_folder_path, folder)
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        img = load_img(file_path, color_mode="grayscale", target_size=(10, 10))
        img_array = img_to_array(img).astype('uint8') // 255
        data.append(img_array.flatten())
        labels.append(folder)

X = np.array(data)
y = np.array(labels)

# Convert labels to categorical format
label_classes = np.unique(y)
label_encoder = {label: i for i, label in enumerate(label_classes)}
y_encoded = to_categorical([label_encoder[label] for label in y])

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.3, random_state=42)

hidden_layer_nodes = [10, 50, 100]

for nodes in hidden_layer_nodes:
    # Train the model
    model = Sequential()
    model.add(Dense(nodes, input_dim=100, activation='relu'))
    model.add(Dense(2*nodes, activation='relu'))  # Additional hidden layer
    model.add(Dense(2*nodes, activation='relu'))  # Additional hidden layer
    model.add(Dense(len(label_classes), activation='softmax'))  # Output layer with the number of classes

    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test))

    # Evaluate the model
    loss, accuracy = model.evaluate(X_test, y_test)
    print(f"Model Accuracy: {accuracy}")

# # Save the trained model
# model.save('trained_model.h5')

# # Load the trained model
# new_model = load_model('trained_model.h5')

# Display the predicted labels for the test set
predicted_labels = []

for i in range(len(X_test)):
    test_img = X_test[i].reshape(1, 100)
    prediction = model.predict(test_img)
    predicted_label = folders[np.argmax(prediction)]
    true_label = folders[np.argmax(y_test[i])]
    predicted_labels.append((f"True Label: {true_label}, Predicted Label: {predicted_label}"))

# Display the predicted labels
print("\nPredicted Labels for Test Set:")
for label_info in predicted_labels:
    print(label_info)
